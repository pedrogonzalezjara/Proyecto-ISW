--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: carreras; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE carreras (
    id integer NOT NULL,
    codigo integer NOT NULL,
    nombre character varying(255) NOT NULL,
    escuela_fk integer NOT NULL
);


ALTER TABLE public.carreras OWNER TO postgres;

--
-- Name: carreras_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE carreras_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.carreras_id_seq OWNER TO postgres;

--
-- Name: carreras_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE carreras_id_seq OWNED BY carreras.id;


--
-- Name: colegios; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE colegios (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    desde integer NOT NULL,
    hasta integer NOT NULL,
    comentario character varying(255) NOT NULL,
    estudiante_fk integer,
    funcionario_fk integer,
    docente_fk integer
);


ALTER TABLE public.colegios OWNER TO postgres;

--
-- Name: colegio_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE colegio_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.colegio_id_seq OWNER TO postgres;

--
-- Name: colegio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE colegio_id_seq OWNED BY colegios.id;


--
-- Name: conocimientos; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE conocimientos (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    nivel_fk integer NOT NULL,
    estudiante_fk integer,
    funcionario_fk integer,
    docente_fk integer
);


ALTER TABLE public.conocimientos OWNER TO postgres;

--
-- Name: conocimientos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE conocimientos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.conocimientos_id_seq OWNER TO postgres;

--
-- Name: conocimientos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE conocimientos_id_seq OWNED BY conocimientos.id;


--
-- Name: departamentos; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE departamentos (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    descripcion text,
    facultad_fk integer NOT NULL
);


ALTER TABLE public.departamentos OWNER TO postgres;

--
-- Name: departamentos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE departamentos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.departamentos_id_seq OWNER TO postgres;

--
-- Name: departamentos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE departamentos_id_seq OWNED BY departamentos.id;


--
-- Name: docentes; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE docentes (
    id integer NOT NULL,
    rut character varying(13) NOT NULL,
    nombres character varying(255) NOT NULL,
    apellidos character varying(255) NOT NULL,
    fecha_nacimiento date,
    genero integer DEFAULT 0 NOT NULL,
    direccion character varying(255) NOT NULL,
    telefono character varying(15),
    email character varying(255) NOT NULL,
    departamento_fk integer NOT NULL
);


ALTER TABLE public.docentes OWNER TO postgres;

--
-- Name: docentes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE docentes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.docentes_id_seq OWNER TO postgres;

--
-- Name: docentes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE docentes_id_seq OWNED BY docentes.id;


--
-- Name: escuelas; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE escuelas (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    descripcion text,
    departamento_fk integer NOT NULL
);


ALTER TABLE public.escuelas OWNER TO postgres;

--
-- Name: escuelas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE escuelas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.escuelas_id_seq OWNER TO postgres;

--
-- Name: escuelas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE escuelas_id_seq OWNED BY escuelas.id;


--
-- Name: estudiantes; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE estudiantes (
    id bigint NOT NULL,
    rut character varying(13) NOT NULL,
    nombres character varying(255) NOT NULL,
    apellidos character varying(255) NOT NULL,
    fecha_nacimiento date,
    genero integer DEFAULT 0 NOT NULL,
    direccion character varying(255) NOT NULL,
    telefono character varying(15) NOT NULL,
    email character varying(255) NOT NULL,
    estado character varying(255) NOT NULL,
    carrera_fk integer NOT NULL
);


ALTER TABLE public.estudiantes OWNER TO postgres;

--
-- Name: estudiantes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE estudiantes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.estudiantes_id_seq OWNER TO postgres;

--
-- Name: estudiantes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE estudiantes_id_seq OWNED BY estudiantes.id;


--
-- Name: facultades; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE facultades (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    descripcion text
);


ALTER TABLE public.facultades OWNER TO postgres;

--
-- Name: facultades_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE facultades_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.facultades_id_seq OWNER TO postgres;

--
-- Name: facultades_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE facultades_id_seq OWNED BY facultades.id;


--
-- Name: funcionarios; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE funcionarios (
    id integer NOT NULL,
    rut character varying(13) NOT NULL,
    nombres character varying(255) NOT NULL,
    apellidos character varying(255) NOT NULL,
    fecha_nacimiento date,
    genero integer DEFAULT 0 NOT NULL,
    direccion character varying(255) NOT NULL,
    telefono character varying(15) NOT NULL,
    email character varying(255) NOT NULL,
    departamento_fk integer NOT NULL
);


ALTER TABLE public.funcionarios OWNER TO postgres;

--
-- Name: funcionarios_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE funcionarios_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.funcionarios_id_seq OWNER TO postgres;

--
-- Name: funcionarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE funcionarios_id_seq OWNED BY funcionarios.id;


--
-- Name: instituciones; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE instituciones (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    carrera character varying(255) NOT NULL,
    desde integer NOT NULL,
    hasta integer NOT NULL,
    comentario character varying(255) NOT NULL,
    titulo character varying(255) NOT NULL,
    estudiante_fk integer,
    funcionario_fk integer,
    docente_fk integer
);


ALTER TABLE public.instituciones OWNER TO postgres;

--
-- Name: institucion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE institucion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.institucion_id_seq OWNER TO postgres;

--
-- Name: institucion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE institucion_id_seq OWNED BY instituciones.id;


--
-- Name: liceos; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE liceos (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    desde integer NOT NULL,
    hasta integer NOT NULL,
    comentario character varying(255) NOT NULL,
    estudiante_fk integer,
    funcionario_fk integer,
    docente_fk integer
);


ALTER TABLE public.liceos OWNER TO postgres;

--
-- Name: liceo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE liceo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.liceo_id_seq OWNER TO postgres;

--
-- Name: liceo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE liceo_id_seq OWNED BY liceos.id;


--
-- Name: niveles; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE niveles (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    descripcion character varying(255) NOT NULL
);


ALTER TABLE public.niveles OWNER TO postgres;

--
-- Name: niveles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE niveles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.niveles_id_seq OWNER TO postgres;

--
-- Name: niveles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE niveles_id_seq OWNED BY niveles.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE roles (
    id integer NOT NULL,
    rol character varying(255) NOT NULL,
    descripcion text
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE roles_id_seq OWNED BY roles.id;


--
-- Name: rules_usuarios; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE rules_usuarios (
    id integer NOT NULL,
    usuario_fk integer NOT NULL,
    rol_fk integer NOT NULL
);


ALTER TABLE public.rules_usuarios OWNER TO postgres;

--
-- Name: rules_usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE rules_usuarios_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rules_usuarios_id_seq OWNER TO postgres;

--
-- Name: rules_usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE rules_usuarios_id_seq OWNED BY rules_usuarios.id;


--
-- Name: trabajos; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE trabajos (
    id integer NOT NULL,
    cargo character varying(255) NOT NULL,
    compania character varying(255) NOT NULL,
    desde_mes character varying(20) NOT NULL,
    desde_ano integer NOT NULL,
    hasta_mes character varying(20) NOT NULL,
    hasta_ano integer NOT NULL,
    referencia character varying(255) NOT NULL,
    estudiante_fk integer NOT NULL,
    funcionario_fk integer NOT NULL,
    docente_fk integer NOT NULL
);


ALTER TABLE public.trabajos OWNER TO postgres;

--
-- Name: trabajos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE trabajos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.trabajos_id_seq OWNER TO postgres;

--
-- Name: trabajos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE trabajos_id_seq OWNED BY trabajos.id;


--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE usuarios (
    pk integer NOT NULL,
    rut integer NOT NULL,
    contrasena character varying(255) NOT NULL,
    rol_fk integer NOT NULL
);


ALTER TABLE public.usuarios OWNER TO postgres;

--
-- Name: usuarios_pk_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE usuarios_pk_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuarios_pk_seq OWNER TO postgres;

--
-- Name: usuarios_pk_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE usuarios_pk_seq OWNED BY usuarios.pk;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY carreras ALTER COLUMN id SET DEFAULT nextval('carreras_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY colegios ALTER COLUMN id SET DEFAULT nextval('colegio_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY conocimientos ALTER COLUMN id SET DEFAULT nextval('conocimientos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY departamentos ALTER COLUMN id SET DEFAULT nextval('departamentos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY docentes ALTER COLUMN id SET DEFAULT nextval('docentes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY escuelas ALTER COLUMN id SET DEFAULT nextval('escuelas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY estudiantes ALTER COLUMN id SET DEFAULT nextval('estudiantes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY facultades ALTER COLUMN id SET DEFAULT nextval('facultades_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY funcionarios ALTER COLUMN id SET DEFAULT nextval('funcionarios_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY instituciones ALTER COLUMN id SET DEFAULT nextval('institucion_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY liceos ALTER COLUMN id SET DEFAULT nextval('liceo_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY niveles ALTER COLUMN id SET DEFAULT nextval('niveles_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY roles ALTER COLUMN id SET DEFAULT nextval('roles_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY rules_usuarios ALTER COLUMN id SET DEFAULT nextval('rules_usuarios_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY trabajos ALTER COLUMN id SET DEFAULT nextval('trabajos_id_seq'::regclass);


--
-- Name: pk; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usuarios ALTER COLUMN pk SET DEFAULT nextval('usuarios_pk_seq'::regclass);


--
-- Data for Name: carreras; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO carreras VALUES (8, 21002, 'Bibliotecología y Documentación', 5);
INSERT INTO carreras VALUES (15, 21012, 'Contador Público y Auditor', 4);
INSERT INTO carreras VALUES (16, 21048, 'Ingeniería Comercial', 6);
INSERT INTO carreras VALUES (17, 21015, 'Ingeniería en Administración Agroindustrial', 2);
INSERT INTO carreras VALUES (18, 21081, 'Ingeniería en Comercio Internacional', 6);
INSERT INTO carreras VALUES (19, 21082, 'Ingeniería en Gestión Turística', 2);
INSERT INTO carreras VALUES (20, 21047, 'Arquitectura', 9);
INSERT INTO carreras VALUES (21, 21074, 'Ingeniería Civil en Obras Civiles', 8);
INSERT INTO carreras VALUES (22, 21032, 'Ingeniería en Construcción', 8);
INSERT INTO carreras VALUES (23, 21087, 'Ingeniería Civil en Prevención de Riesgos y Medio Ambiente', 7);
INSERT INTO carreras VALUES (24, 21082, 'Ingeniería en Gestión Turística', 7);
INSERT INTO carreras VALUES (25, 21073, 'Ingeniería en Biotecnología', 11);
INSERT INTO carreras VALUES (26, 3820, 'Ingeniería de Ejecución en Biotecnología', 11);
INSERT INTO carreras VALUES (27, 21088, 'Cartografía y Geomática', 13);
INSERT INTO carreras VALUES (28, 21024, 'Diseño en Comunicación Visual', 12);
INSERT INTO carreras VALUES (29, 21023, 'Diseño Industrial', 12);
INSERT INTO carreras VALUES (30, 21043, 'Trabajo Social', 14);
INSERT INTO carreras VALUES (31, 21046, 'Bachillerato en Ciencias de la Ingeniería', 17);
INSERT INTO carreras VALUES (32, 21071, 'Dibujante Proyectista', 12);
INSERT INTO carreras VALUES (33, 21041, 'Ingeniería Civil en Computación mención Informática', 16);
INSERT INTO carreras VALUES (34, 21076, 'Ingeniería Civil Industrial', 17);
INSERT INTO carreras VALUES (35, 21075, 'Ingeniería Civil Electrónica', 18);
INSERT INTO carreras VALUES (36, 21031, 'Ingeniería en Geomensura', 17);
INSERT INTO carreras VALUES (37, 21030, 'Ingeniería en Informática', 16);
INSERT INTO carreras VALUES (38, 21037, 'Ingeniería en Mecánica', 19);
INSERT INTO carreras VALUES (39, 21025, 'Ingeniería en Transporte y Tránsito', 17);
INSERT INTO carreras VALUES (40, 21045, 'Ingeniería Industrial', 17);


--
-- Name: carreras_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('carreras_id_seq', 40, true);


--
-- Name: colegio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('colegio_id_seq', 6, true);


--
-- Data for Name: colegios; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO colegios VALUES (5, 'saasdasd', 2008, 20010, 'sadsadd', NULL, NULL, NULL);
INSERT INTO colegios VALUES (6, 'sdassda', 5005, 2012, 'dasdasd', NULL, NULL, NULL);


--
-- Data for Name: conocimientos; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Name: conocimientos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('conocimientos_id_seq', 1, false);


--
-- Data for Name: departamentos; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO departamentos VALUES (2, 'Departamento de Economía , Recursos Naturales y Comercio Internacional', 'Dirección: Dr. Hernán Alessandri 722, ProvidenciaTeléfono: (56-2) 2787 7939', 1);
INSERT INTO departamentos VALUES (13, 'Departamento de Contabilidad y Gestión Financiera', 'Dirección: Dr. Hernán Alessandri 722, Providencia Teléfono: (56-2) 2787 7985', 1);
INSERT INTO departamentos VALUES (15, 'Departamento de Estadística y Econometría', 'Dirección: Dr. Hernán Alessandri 722, Providencia Teléfono: (56-2) 2787 7994', 1);
INSERT INTO departamentos VALUES (14, 'Departamento de Gestión de la Información ', 'Dirección: Dr. Hernán Alessandri 722, Providencia  Teléfono: (56-2) 2787 7960 ', 1);
INSERT INTO departamentos VALUES (1, 'Departamento de Gestión Organizacional', 'Dirección: Dr. Hernán Alessandri 722, ProvidenciaTeléfonos: (56-2) 2787 7928 – 2787 7997', 1);
INSERT INTO departamentos VALUES (21, 'Departamento de Prevención de Riesgos y Medio Ambiente', 'Dirección: Dieciocho 390, Santiago Teléfono: (56-2) 787 7312', 2);
INSERT INTO departamentos VALUES (22, 'Departamento de Ciencias de la Construcción', 'Dirección: Dieciocho 390, Santiago Teléfono: (56-2) 787 7306', 2);
INSERT INTO departamentos VALUES (23, 'Departamento de Planificación y Ordenamiento Territorial', 'Dirección: Dieciocho 390, Santiago Teléfono: (56-2) 787 7331', 2);
INSERT INTO departamentos VALUES (24, 'Departamento de Química', 'Dirección: José Pedro Alessandri 1242, Ñuñoa Teléfono: (56-2) 787 7127', 3);
INSERT INTO departamentos VALUES (25, 'Departamento de Matemáticas', 'Dirección: José Pedro Alessandri 1242, Ñuñoa Teléfono: (56-2) 787 7221', 3);
INSERT INTO departamentos VALUES (26, 'Departamento de Física', 'Dirección: José Pedro Alessandri 1242, Ñuñoa Teléfono: (56-2) 787 7164', 3);
INSERT INTO departamentos VALUES (27, 'Departamento de Biotecnología', 'Dirección: José Pedro Alessandri 1242, Ñuñoa Teléfono: (56-2) 787 7160', 3);
INSERT INTO departamentos VALUES (28, 'Departamento de Diseño', 'Dirección: Dieciocho N° 390, Santiago Teléfono: (56-2) 787 7315', 4);
INSERT INTO departamentos VALUES (29, 'Departamento de Cartografía', 'Dirección: San Ignacio N° 171, Santiago Teléfono: (56-2) 787 7630', 4);
INSERT INTO departamentos VALUES (30, 'Departamento de Trabajo Social', 'Dirección: Vidaurre N° 1550, Santiago Teléfono: (56-2) 698 2297', 4);
INSERT INTO departamentos VALUES (31, 'Departamento de Humanidades', 'Dirección: Alonso Ovalle N° 1618 C, Santiago Teléfono: (56-2) 699 4131 – 787 7607', 4);
INSERT INTO departamentos VALUES (32, 'Departamento de Informática y Computación', 'Dirección: José Pedro Alessandri 1242, Ñuñoa Teléfono: (56-2) 787 7211', 5);
INSERT INTO departamentos VALUES (33, 'Departamento de Industria', 'Dirección: José Pedro Alessandri 1242, Ñuñoa Teléfono: (56-2) 787 7108', 5);
INSERT INTO departamentos VALUES (34, 'Departamento de Electricidad', 'Dirección: José Pedro Alessandri 1242, Ñuñoa Teléfono: (56-2) 787 7119', 5);
INSERT INTO departamentos VALUES (35, 'Departamento de Mecánica', 'Dirección: José Pedro Alessandri 1242, Ñuñoa Teléfono: (56-2) 787 7135', 5);


--
-- Name: departamentos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('departamentos_id_seq', 35, true);


--
-- Data for Name: docentes; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO docentes VALUES (1, '18546929-l', 'Juan', 'Perez', NULL, 1, 'Asdasdasd', '86846848', 'dsfasdsadasd', 1);
INSERT INTO docentes VALUES (2, '16.311.003-2', 'Jimmy Jonathan', 'Madariaga Leiva', '1987-11-19', 1, 'Rosas #2223, Santiago', '78945612', 'jimmyqlo@enterogay.cl', 1);


--
-- Name: docentes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('docentes_id_seq', 2, true);


--
-- Data for Name: escuelas; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO escuelas VALUES (2, 'Escuela de Administración  ', 'Dirección: Dr. Hernán Alessandri 644, Providencia Teléfono: (56-2) 2787 7929 – 2787 7984', 1);
INSERT INTO escuelas VALUES (3, 'Escuela de Comercio Internacional  ', 'Dirección: Dr. Hernán Alessandri 644, Providencia Teléfono: (56-2) 787 7932 – 787 7933 – 787 7935 http://comerciointernacional.blogutem.cl/', 2);
INSERT INTO escuelas VALUES (4, 'Escuela de Contadores Auditores ', ' Dirección: Dr. Hernán Alessandri 644, Providencia Teléfono: (56-2) 2787 7983 – 2787 7957', 13);
INSERT INTO escuelas VALUES (5, 'Escuela de Bibliotecología ', ' Teléfono: (56-2) 2787 7963 – 2787 7964 Dirección: Dr. Hernán Alessandri 722, Providencia', 14);
INSERT INTO escuelas VALUES (6, 'Escuela de Ingeniería Comercial  ', 'Dirección: Dr. Hernán Alessandri 644, Providencia Teléfono: (56-2) 2787 7990 – 2787 7972', 15);
INSERT INTO escuelas VALUES (7, 'Escuela de Prevención de Riesgos y Medio Ambiente', 'Dirección: Dieciocho 390, Santiago Teléfono: (56-2) 787 7311', 21);
INSERT INTO escuelas VALUES (8, 'Escuela de Construcción Civil', 'Dirección: Dieciocho 390, Santiago Teléfono: (56-2) 787 7308', 22);
INSERT INTO escuelas VALUES (9, 'Escuela de Arquitectura', 'Dirección: Dieciocho 390 – San Ignacio 405 Teléfono: (56-2) 787 7310 – 787 7313 – 787 7352', 22);
INSERT INTO escuelas VALUES (10, 'Escuela de Química', 'Dirección: José Pedro Alessandri 1242, Ñuñoa Teléfono: (56-2) 787 7217', 24);
INSERT INTO escuelas VALUES (11, 'Escuela de Ingeniería en Industria Alimentaria', 'Dirección: José Pedro Alessandri 1242, Ñuñoa Teléfono: (56-2) 787 7098', 27);
INSERT INTO escuelas VALUES (12, 'Escuela de Diseño', 'Teléfono: (56-2) 787 7335 – 787 7333 – 787 7334 Dirección: Dieciocho N° 390, Santiago', 28);
INSERT INTO escuelas VALUES (13, 'Escuela de Cartografía', 'Dirección: San Ignacio N° 171, Santiago Teléfono: (56-2) 787 7507 – 787 7630', 29);
INSERT INTO escuelas VALUES (14, 'Escuela de Trabajo Social', 'Dirección: Vidaurre N° 1550, Santiago Teléfono: (56-2) 696 7553 – 787 7588', 30);
INSERT INTO escuelas VALUES (15, 'Escuela de Criminalística Forense', 'Dirección: Calle Dieciocho N° 109, Santiago Teléfono: (56-2) 787 7569 – 671 8250 – 6718197', 23);
INSERT INTO escuelas VALUES (16, 'Escuela de Informática', 'Dirección: Avenida José Pedro Alessandri 1242, Ñuñoa Teléfono: (56-2) 787 7100', 32);
INSERT INTO escuelas VALUES (17, 'Escuela de Industria', 'Dirección: José Pedro Alessandri 1242, Ñuñoa Teléfono: (56-2) 787 7035', 33);
INSERT INTO escuelas VALUES (18, 'Escuela de Electrónica', 'Dirección: José Pedro Alessandri 1242, Ñuñoa Fono: (56-2) 787 7034', 34);
INSERT INTO escuelas VALUES (19, 'Escuela de Mecánica', 'Dirección: José Pedro Alessandri 1242, Ñuñoa Teléfono: (56-2) 787 7169 –  (56-2) 787 7039 - (56-2) 787 7045', 35);
INSERT INTO escuelas VALUES (20, 'Escuela de Industria de la Madera', 'Dirección: José Pedro Alessandri 1242, Ñuñoa Teléfono: (56-2) 787 7045 – 787 7105', 33);
INSERT INTO escuelas VALUES (21, 'Escuela de Geomensura', 'Dirección: José Pedro Alessandri 1242 Teléfono: (56-2) 787 71 11', 33);
INSERT INTO escuelas VALUES (22, 'Escuela de Transporte y Tránsito', 'Teléfono: (56-2) 787 71 57 – 787 70 30 Dirección: Avda. José Pedro Alessandri 1242, Ñuñoa', 33);


--
-- Name: escuelas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('escuelas_id_seq', 22, true);


--
-- Data for Name: estudiantes; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO estudiantes VALUES (29, '177008982', 'Marco Antonio', 'Palacios Fuentes', NULL, 1, 'El Solar #7981 Santiago', '92397250', 'marco.palacios.fuentes@gmail.com', 'Soltero', 8);
INSERT INTO estudiantes VALUES (33, '18.515.550-2', 'Sergio Andres', 'Madariaga Castro', '1993-03-23', 1, 'Rosas #2223 Santiago', '89564578', 'sergio@correo.com', 'Sotero', 8);
INSERT INTO estudiantes VALUES (36, '17.746.323-k', 'Dsfds', 'Asdasd', '0789-10-05', 1, 'Asdsa', '98746846', 'sdsds', 'Dasdasd', 8);


--
-- Name: estudiantes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('estudiantes_id_seq', 36, true);


--
-- Data for Name: facultades; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO facultades VALUES (2, 'Ciencias de la Construcción y Ordenamiento Territorial', 'La Facultad de Ciencias de la Construcción y Ordenamiento Territorial está ubicada en el Campus Área Central en la calle Dieciocho 390 Santiago Centro, Metro Toesca.');
INSERT INTO facultades VALUES (3, 'Ciencias Naturales, Matemática y del Medio Ambiente', 'La Facultad de Ciencias Naturales, Matemática y Medio Ambiente está ubicada en el Campus Macul en Av. José Pedro Alessandri 1242, Ñuñoa, Santiago.');
INSERT INTO facultades VALUES (4, 'Humanidades y Tecnologías de la Comunicación Social', 'La Facultad de Humanidades y Tecnologías de la Comunicación Social está ubicada en el Campus Área Central en Dieciocho 390, Santiago Centro, Metro Toesca.');
INSERT INTO facultades VALUES (5, 'Ingeniería', 'La Facultad de Ingeniería está ubicada en el Campus Macul, en Av. José Pedro Alessandri 1242, Ñuñoa, Santiago.');
INSERT INTO facultades VALUES (1, 'Administración y Economía', 'La Facultad de Administración y Economía está ubicada en el Campus Providencia en Dr. Hernán Alessandri 722, Providencia, Metro Salvador.');


--
-- Name: facultades_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('facultades_id_seq', 10, true);


--
-- Data for Name: funcionarios; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Name: funcionarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('funcionarios_id_seq', 2, true);


--
-- Name: institucion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('institucion_id_seq', 1, false);


--
-- Data for Name: instituciones; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Name: liceo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('liceo_id_seq', 1, false);


--
-- Data for Name: liceos; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: niveles; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Name: niveles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('niveles_id_seq', 1, false);


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO roles VALUES (1, '1', 'administrador');
INSERT INTO roles VALUES (2, '2', 'estudiante');
INSERT INTO roles VALUES (3, '3', 'funcionario');
INSERT INTO roles VALUES (4, '4', 'docente');


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('roles_id_seq', 5, true);


--
-- Data for Name: rules_usuarios; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Name: rules_usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('rules_usuarios_id_seq', 1, false);


--
-- Data for Name: trabajos; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Name: trabajos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('trabajos_id_seq', 1, false);


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Name: usuarios_pk_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('usuarios_pk_seq', 1, false);


--
-- Name: carreras_codigo_escuela_fk_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY carreras
    ADD CONSTRAINT carreras_codigo_escuela_fk_key UNIQUE (codigo, escuela_fk);


--
-- Name: carreras_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY carreras
    ADD CONSTRAINT carreras_pkey PRIMARY KEY (id);


--
-- Name: colegio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY colegios
    ADD CONSTRAINT colegio_pkey PRIMARY KEY (id);


--
-- Name: conocimientos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY conocimientos
    ADD CONSTRAINT conocimientos_pkey PRIMARY KEY (id);


--
-- Name: departamentos_nombre_facultad_fk_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY departamentos
    ADD CONSTRAINT departamentos_nombre_facultad_fk_key UNIQUE (nombre, facultad_fk);


--
-- Name: departamentos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY departamentos
    ADD CONSTRAINT departamentos_pkey PRIMARY KEY (id);


--
-- Name: docentes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY docentes
    ADD CONSTRAINT docentes_pkey PRIMARY KEY (id);


--
-- Name: docentes_rut_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY docentes
    ADD CONSTRAINT docentes_rut_key UNIQUE (rut);


--
-- Name: escuelas_nombre_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY escuelas
    ADD CONSTRAINT escuelas_nombre_key UNIQUE (nombre);


--
-- Name: escuelas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY escuelas
    ADD CONSTRAINT escuelas_pkey PRIMARY KEY (id);


--
-- Name: estudiantes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY estudiantes
    ADD CONSTRAINT estudiantes_pkey PRIMARY KEY (id);


--
-- Name: estudiantes_rut_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY estudiantes
    ADD CONSTRAINT estudiantes_rut_key UNIQUE (rut);


--
-- Name: facultades_nombre_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY facultades
    ADD CONSTRAINT facultades_nombre_key UNIQUE (nombre);


--
-- Name: facultades_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY facultades
    ADD CONSTRAINT facultades_pkey PRIMARY KEY (id);


--
-- Name: funcionarios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY funcionarios
    ADD CONSTRAINT funcionarios_pkey PRIMARY KEY (id);


--
-- Name: funcionarios_rut_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY funcionarios
    ADD CONSTRAINT funcionarios_rut_key UNIQUE (rut);


--
-- Name: institucion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY instituciones
    ADD CONSTRAINT institucion_pkey PRIMARY KEY (id);


--
-- Name: liceo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY liceos
    ADD CONSTRAINT liceo_pkey PRIMARY KEY (id);


--
-- Name: niveles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY niveles
    ADD CONSTRAINT niveles_pkey PRIMARY KEY (id);


--
-- Name: roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: roles_rol_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY roles
    ADD CONSTRAINT roles_rol_key UNIQUE (rol);


--
-- Name: rules_usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY rules_usuarios
    ADD CONSTRAINT rules_usuarios_pkey PRIMARY KEY (id);


--
-- Name: rules_usuarios_usuario_fk_rol_fk_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY rules_usuarios
    ADD CONSTRAINT rules_usuarios_usuario_fk_rol_fk_key UNIQUE (usuario_fk, rol_fk);


--
-- Name: trabajos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY trabajos
    ADD CONSTRAINT trabajos_pkey PRIMARY KEY (id);


--
-- Name: usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (pk);


--
-- Name: usuarios_rut_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY usuarios
    ADD CONSTRAINT usuarios_rut_key UNIQUE (rut);


--
-- Name: carreras_escuela_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY carreras
    ADD CONSTRAINT carreras_escuela_fk_fkey FOREIGN KEY (escuela_fk) REFERENCES escuelas(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: colegio_docente_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY colegios
    ADD CONSTRAINT colegio_docente_fk_fkey FOREIGN KEY (docente_fk) REFERENCES docentes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: colegio_estudiante_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY colegios
    ADD CONSTRAINT colegio_estudiante_fk_fkey FOREIGN KEY (estudiante_fk) REFERENCES estudiantes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: colegio_funcionario_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY colegios
    ADD CONSTRAINT colegio_funcionario_fk_fkey FOREIGN KEY (funcionario_fk) REFERENCES funcionarios(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: conocimientos_docente_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY conocimientos
    ADD CONSTRAINT conocimientos_docente_fk_fkey FOREIGN KEY (docente_fk) REFERENCES docentes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: conocimientos_estudiante_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY conocimientos
    ADD CONSTRAINT conocimientos_estudiante_fk_fkey FOREIGN KEY (estudiante_fk) REFERENCES estudiantes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: conocimientos_funcionario_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY conocimientos
    ADD CONSTRAINT conocimientos_funcionario_fk_fkey FOREIGN KEY (funcionario_fk) REFERENCES funcionarios(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: conocimientos_nivel_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY conocimientos
    ADD CONSTRAINT conocimientos_nivel_fk_fkey FOREIGN KEY (nivel_fk) REFERENCES niveles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: departamentos_facultad_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY departamentos
    ADD CONSTRAINT departamentos_facultad_fk_fkey FOREIGN KEY (facultad_fk) REFERENCES facultades(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: docentes_departamento_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY docentes
    ADD CONSTRAINT docentes_departamento_fk_fkey FOREIGN KEY (departamento_fk) REFERENCES departamentos(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: escuelas_departamento_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY escuelas
    ADD CONSTRAINT escuelas_departamento_fk_fkey FOREIGN KEY (departamento_fk) REFERENCES departamentos(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: estudiantes_carrera_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY estudiantes
    ADD CONSTRAINT estudiantes_carrera_fk_fkey FOREIGN KEY (carrera_fk) REFERENCES carreras(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: funcionarios_departamento_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY funcionarios
    ADD CONSTRAINT funcionarios_departamento_fk_fkey FOREIGN KEY (departamento_fk) REFERENCES departamentos(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: institucion_docente_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY instituciones
    ADD CONSTRAINT institucion_docente_fk_fkey FOREIGN KEY (docente_fk) REFERENCES docentes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: institucion_estudiante_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY instituciones
    ADD CONSTRAINT institucion_estudiante_fk_fkey FOREIGN KEY (estudiante_fk) REFERENCES estudiantes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: institucion_funcionario_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY instituciones
    ADD CONSTRAINT institucion_funcionario_fk_fkey FOREIGN KEY (funcionario_fk) REFERENCES funcionarios(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: liceo_docente_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY liceos
    ADD CONSTRAINT liceo_docente_fk_fkey FOREIGN KEY (docente_fk) REFERENCES docentes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: liceo_estudiante_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY liceos
    ADD CONSTRAINT liceo_estudiante_fk_fkey FOREIGN KEY (estudiante_fk) REFERENCES estudiantes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: liceo_funcionario_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY liceos
    ADD CONSTRAINT liceo_funcionario_fk_fkey FOREIGN KEY (funcionario_fk) REFERENCES funcionarios(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: trabajos_docente_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY trabajos
    ADD CONSTRAINT trabajos_docente_fk_fkey FOREIGN KEY (docente_fk) REFERENCES docentes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: trabajos_estudiante_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY trabajos
    ADD CONSTRAINT trabajos_estudiante_fk_fkey FOREIGN KEY (estudiante_fk) REFERENCES estudiantes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: trabajos_funcionario_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY trabajos
    ADD CONSTRAINT trabajos_funcionario_fk_fkey FOREIGN KEY (funcionario_fk) REFERENCES funcionarios(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: usuarios_rol_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usuarios
    ADD CONSTRAINT usuarios_rol_fk_fkey FOREIGN KEY (rol_fk) REFERENCES roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

